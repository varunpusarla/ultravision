****************INSTRUCTIONS***********************

STEP1: Turn on with manual power button.
STEP2: Set the range of sensors.
STEP3: Just walk around and change your direction when the buzzer sounds.
STEP4: Turn off the power button after use.

